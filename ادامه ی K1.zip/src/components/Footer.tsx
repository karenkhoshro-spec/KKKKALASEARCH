import { Link } from "react-router-dom";
import { useLanguage } from "../i18n/LanguageContext";
import OrderXLogo from "./OrderXLogo";
import "./Footer.css";

export default function Footer() {
  const { t, dir } = useLanguage();

  return (
    <footer className="ks-footer mt-10 border-t" style={{ borderColor: "var(--border-soft)" }}>
      <div className="mx-auto max-w-6xl px-4 pt-7 pb-12 sm:px-6">
        <div className="ks-footer-brand-wrap mb-6 flex flex-col items-center overflow-visible text-center">
          <Link to="/" aria-label="OrderX — بازگشت به صفحه اصلی" className="ks-footer-brand inline-flex justify-center overflow-visible">
            <OrderXLogo />
          </Link>
          <p className="mt-2.5 max-w-md text-xs sm:text-sm leading-6" style={{ color: "var(--text-secondary)" }}>
            {t("footer.about")}
          </p>
        </div>

        <div className="border-t pt-6" style={{ borderColor: "var(--border-soft)" }} dir={dir}>
          <h4 className="mb-3 text-center text-sm font-bold" style={{ color: "var(--text-primary)" }}>
            {t("footer.quickLinks")}
          </h4>
          <ul className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-sm" style={{ color: "var(--text-secondary)" }}>
            <li><Link to="/" className="ks-footer-link">{t("menu.home")}</Link></li>
            <li><Link to="/products" className="ks-footer-link">{t("menu.products")}</Link></li>
            <li><Link to="/" className="ks-footer-link">{t("menu.categories")}</Link></li>
            <li><Link to="/search" className="ks-footer-link">{t("home.searchCta")}</Link></li>
            <li><Link to="/account" className="ks-footer-link">{t("menu.account")}</Link></li>
            <li><Link to="/cart" className="ks-footer-link">{t("menu.cart")}</Link></li>
          </ul>
        </div>

        <div className="mt-8 border-t pt-5 text-center text-xs" style={{ borderColor: "var(--border-soft)", color: "var(--text-muted)" }}>
          © {new Date().getFullYear()} OrderX — {t("footer.rights")}
        </div>
      </div>
    </footer>
  );
}
